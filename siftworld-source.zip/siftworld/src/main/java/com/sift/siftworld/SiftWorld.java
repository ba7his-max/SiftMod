package com.sift.siftworld;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.Commands;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class SiftWorld implements ModInitializer {
	public static final String MOD_ID = "siftworld";

	/** Stored on the player, so the starter kit is only ever given once. */
	private static final String KIT_TAG = "siftworld_kit_given";

	public static Block PINK_END_STONE;
	public static Item PINK_END_STONE_ITEM;

	@Override
	public void onInitialize() {
		registerPinkEndStone();
		registerStarterKit();
		registerCommand();
	}

	private static void registerPinkEndStone() {
		Identifier id = Identifier.fromNamespaceAndPath(MOD_ID, "pink_end_stone");
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);

		PINK_END_STONE = Registry.register(BuiltInRegistries.BLOCK, blockKey,
				new PinkEndStoneBlock(BlockBehaviour.Properties.of()
						.setId(blockKey)
						.mapColor(MapColor.COLOR_PINK)
						.strength(3.0F, 9.0F)
						.requiresCorrectToolForDrops()
						.sound(SoundType.STONE)
						.lightLevel(state -> state.getValue(PinkEndStoneBlock.LIT) ? 15 : 0)));

		PINK_END_STONE_ITEM = Registry.register(BuiltInRegistries.ITEM, itemKey,
				new BlockItem(PINK_END_STONE, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix()));
	}

	private static void registerStarterKit() {
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			ServerPlayer player = handler.getPlayer();
			if (player.getTags().contains(KIT_TAG)) {
				return;
			}
			player.addTag(KIT_TAG);
			player.getInventory().placeItemBackInInventory(new ItemStack(PINK_END_STONE_ITEM, 12));
			player.getInventory().placeItemBackInInventory(new ItemStack(Items.WATER_BUCKET, 1));
		});
	}

	/** /sift goes to the Sift dimension, /sift back returns to the Overworld. */
	private static void registerCommand() {
		CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) ->
				dispatcher.register(Commands.literal("sift")
						.executes(ctx -> travel(ctx.getSource().getPlayerOrException(), "siftworld:sift", "the Sift world"))
						.then(Commands.literal("back")
								.executes(ctx -> travel(ctx.getSource().getPlayerOrException(), "minecraft:overworld", "the Overworld")))));
	}

	private static int travel(ServerPlayer player, String dimension, String label) {
		MinecraftServer server = player.level().getServer();
		String who = player.getStringUUID();
		String command = "execute as " + who + " in " + dimension
				+ " positioned 0 0 0 positioned over world_surface run tp @s ~ ~1 ~";
		server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), command);
		player.sendSystemMessage(Component.literal("Welcome to " + label + "!"));
		return Command.SINGLE_SUCCESS;
	}
}
