# Sift World (Fabric, Minecraft 26.2)

## What it does
- Adds **Pink End Stone**, a new block and item. Vanilla End Stone is not changed.
- Pink End Stone **lights up** (light level 15) when water touches it.
- New players get **12 Pink End Stone + 1 Water Bucket** the first time they join a world (once only).
- Adds the **Sift dimension**: a full world with every vanilla biome, caves, ice caves, trees and mobs.
  - `/sift` goes there, `/sift back` returns to the Overworld.
- **Requires Fabric API.** It is NOT included in the mod. Without it the game shows a missing-dependency error.

## Install (players)
1. Install Fabric Loader 0.19.3 or newer for 26.2 (https://fabricmc.net/use/installer/).
2. Download Fabric API for 26.2 from https://modrinth.com/mod/fabric-api or https://www.curseforge.com/minecraft/mc-mods/fabric-api and put it in `mods`.
3. Put `siftworld-1.0.0.jar` in `mods`.

## Build (needs Java 25)
1. Install JDK 25.
2. This folder has no Gradle wrapper. Get one by either:
   - installing Gradle 9.5.1 and running `gradle wrapper --gradle-version 9.5.1`, or
   - copying `gradlew`, `gradlew.bat` and the `gradle/` folder from the Fabric template at https://fabricmc.net/develop/template/
3. Run `./gradlew build` (Windows: `gradlew build`).
4. The mod jar is in `build/libs/siftworld-1.0.0.jar` (use the one without `-sources`).

If `fabric_api_version` in `gradle.properties` is not found, copy the current 26.2 value from https://fabricmc.net/develop.
